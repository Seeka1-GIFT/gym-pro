const s={members:{root:["members"],list:e=>["members","list",e],detail:e=>["members","detail",e]},stats:{overview:["stats","overview"]}};export{s as q};
