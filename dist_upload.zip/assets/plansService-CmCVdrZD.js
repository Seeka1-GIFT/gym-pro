import{a as t}from"./index-Be1RE_nH.js";import{n}from"./paginate-h10ngajL.js";async function r(){const{data:a}=await t.get("/api/plans");return n(a,1,50)}export{r as l};
