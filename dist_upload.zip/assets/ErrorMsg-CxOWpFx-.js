import{f as s,j as e}from"./index-Be1RE_nH.js";/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=s("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=s("RefreshCw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]]);/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=s("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]),x=({title:r,message:c,onDismiss:t,onRetry:d,className:l=""})=>e.jsx("div",{className:`bg-red-50 border border-red-200 rounded-md p-4 ${l}`,children:e.jsxs("div",{className:"flex",children:[e.jsx("div",{className:"flex-shrink-0",children:e.jsx(n,{className:"h-5 w-5 text-red-400"})}),e.jsxs("div",{className:"ml-3 flex-1",children:[r&&e.jsx("h3",{className:"text-sm font-medium text-red-800 mb-1",children:r}),e.jsx("p",{className:"text-sm text-red-800",children:c})]}),e.jsxs("div",{className:"ml-auto pl-3 flex space-x-2",children:[d&&e.jsx("button",{type:"button",onClick:d,className:"inline-flex bg-red-50 rounded-md p-1.5 text-red-500 hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-red-50 focus:ring-red-600",title:"Retry",children:e.jsx(i,{className:"h-3 w-3"})}),t&&e.jsx("button",{type:"button",onClick:t,className:"inline-flex bg-red-50 rounded-md p-1.5 text-red-500 hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-red-50 focus:ring-red-600",title:"Dismiss",children:e.jsx(o,{className:"h-3 w-3"})})]})]})});export{x as E};
